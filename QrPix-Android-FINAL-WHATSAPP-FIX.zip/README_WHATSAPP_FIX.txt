QrPix Android - correção do envio para WhatsApp

Nesta versão, o botão "Enviar por WhatsApp" usa a área de transferência nativa do Android
quando o aplicativo está rodando dentro da WebView. O código Pix é copiado pelo Android
antes de abrir o WhatsApp.

Fallbacks mantidos:
1. Clipboard nativo Android
2. navigator.clipboard da WebView
3. document.execCommand('copy')

Nenhuma alteração foi feita na lógica de geração do Pix/QR Code.

# QrPix Android

Projeto Android que abre o QrPix HTML localmente em uma WebView, sem depender do Google Chrome.

O conteúdo do QrPix é empacotado em `app/src/main/assets/`.

O workflow em `.github/workflows/build-apk.yml` gera o APK Debug no GitHub Actions.

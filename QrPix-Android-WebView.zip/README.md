# QrPix Android — WebView

Este projeto transforma o QrPix HTML em um APK Android independente de abrir o Google Chrome.

O HTML é carregado de dentro do próprio APK em `app/src/main/assets/`.

Pacote: `io.github.cristianorodrigurssilva_pixel.qrpix`

A primeira versão mantém a biblioteca QRCode.js referenciada pelo `index.html`. Para uma versão 100% offline, a biblioteca deve ser incorporada aos assets e o `index.html` deve apontar para o arquivo local.

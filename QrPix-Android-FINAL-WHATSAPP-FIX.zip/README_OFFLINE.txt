QrPix Android - versão preparada para APK

Projeto Android com WebView para abrir o QrPix sem depender do Google Chrome.

IMPORTANTE:
- O HTML fica dentro do APK.
- A WebView executa o aplicativo dentro do próprio QrPix.
- O workflow usa Gradle instalado pelo GitHub Actions e não depende de gradlew.
- Para QR Code funcionar completamente offline, a biblioteca qrcodejs deve estar incluída localmente em app/src/main/assets.
